#########################################################################
#                                                                       #
#     Thank you for downloading The Riemannian Staircase Method.        #
#                                                                       #
#########################################################################

#
#     To get started:
#
#              Download and install Manopt from www.manopt.org, then
#              Read and run example.m.
#

#
#     Feedback and questions welcome: nicolasboumal@gmail.com
#

#
#     This is open source software, distributed under BSD license
#     (See LICENSE.TXT)
#


This zip file was released on June 6, 2014. This is version 1.1.


---------------------------------------------------------------------------


This is Matlab code to solve convex optimization problems over the cone of
positive semidefinite matrices with diagonal block constraints. The main
tool is optimization on manifolds, which is executed via the Manopt toolbox:

    www.manopt.org.

Please download the latest version of Manopt on the website.

The best way to get started is to read and run example.m.
It will generate a random instance of a synchronization problem and solve
it in different ways.

A paper describing this algorithm will appear after the release date of
this file. Please consult my webpage to cite the reference when it comes out.

Enjoy,
Nicolas