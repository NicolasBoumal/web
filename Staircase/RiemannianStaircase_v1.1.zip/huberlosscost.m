function problem = huberlosscost(data, epsilon, p)
% function problem = huberlosscost(data, epsilon, p)
%
% Returns a Manopt problem structure corresponding to the problem
%
%   min Sum_{i~j} huber(norm(C_ij Y_j - Y_i, 'fro'))
% 
%     such that Y has size n x p (n = m*d) and is divided in m
%     blocks of size d x p each, called Y_i, i = 1 : m. Each Y_i is
%     constrained to be orthonormal: Y_i*Y_i' = eye(d). The sum is over the
%     edges of a graph described in the data structure. Huber is the huber
%     loss function, a smoothed version of the absolute value function,
%     with smoothing parameter epsilon. The close epsilon is to zero, the
%     close huber looks like the absolute value function, but the harder
%     the problem becomes from a numerical points of view. It is typically
%     better to start with a reasonable value of espilon (say, .1) and to
%     decrease that value, using the previous estimator as initial guess.
%
%     The data structure describes the blocks C_ij and the graph on which
%     they are defined. You may obtain such a structure by calling
%     prepare_data.
%
% This corresponds to constraining the matrix X = Y*Y' to be symmetric,
% positive semidefinite with rank(X) <= p and the m diagonal blocks of X of
% size dxd each equal eye(d).
%
% If, when solving this problem, the returned Y is a rank-deficient local
% optimizer of this problem, than X = Y*Y' is a global optimizer of the
% convex program which consists in minimizing the same cost function such
% that X is as described above. Numerically, one can check for rank
% deficiency by checking rank(Y'*Y) < p (not rank(Y*Y')). You may also
% compute cond(Y) and compare it against a chosen large number (the larger
% cond(Y), the closer Y is to rank deficiency).
%
% To solve the problem, call one of Manopt's solvers. For example:
%
% Y = trustregions(problem);
%
% will use Riemannian Trust-Regions with a random initial guess and default
% options. See www.manopt.org for more help.
%
% See also huberlosscost_staircase prepare_data linearcost round2orthogonal
%
% Nicolas Boumal, UCLouvain, March 4, 2014.
    
    % Extract data from the synchronization problem structure.
    % Such a data structure is obtained from prepare_data.
    %
    m = data.m; % number of orthonormal matrices to find
    d = data.d; % dimension of the ambient space
    k = data.k; % the number of measurements available
    C = data.C; % data on the edges
    I = data.I; % edges of the graph
    J = data.J;
    maskI = data.maskI;
    maskJ = data.maskJ;
    
    manifold = stiefelstackedfactory(m, d, p);
    problem.M = manifold;
    
    % Huber loss, assuming x >= 0.
    function y = phi(x)
        y = zeros(size(x));
        e = epsilon;
        mask = (x < e);
        y( mask) = x( mask).^2 / (2*e);
        y(~mask) = x(~mask) - e/2;
    end

    % Derivative of phi at x, divided by x. Still assuming x >= 0.
    % By continuous prolongation, dphi_x(0) = 1/epsilon.
    function y = dphi_x(x)
        y = zeros(size(x));
        e = epsilon;
        mask = (x < e);
        y( mask) = 1/e;
        y(~mask) = 1./x(~mask);
    end

    % Cost function. Remember that Y is given as a 2D array which is
    % implicitly "sliced" in as many orthonormal matrices as there are
    % diagonal blocks in the constraints. The function manifold.to3D()
    % transforms the 2D array in a 3D array to ease access to these slices.
    % The function manifold.to2D() reverts that change.
    problem.cost = @cost;
    function f = cost(Y)
        
        R = manifold.to3D(Y);
        
        Ri = R(:, :, I);
        Rj = R(:, :, J);
        residues = multiprod(C, Rj) - Ri;
        residues_norms = sqrt(multisqnorm(residues));
        f = sum(phi(residues_norms)) / k;
        
    end

    % Classical (Euclidean) gradient of the cost function. It will be
    % transformed into the Riemannian gradient automatically by Manopt.
    problem.egrad = @egrad;
    function G = egrad(Y)
        
        R = manifold.to3D(Y);
        G = zeros(size(R));
        
        Ri = R(:, :, I);
        Rj = R(:, :, J);
        residues = multiprod(C, Rj) - Ri;
        residues_norms = sqrt(multisqnorm(residues));
        
        weights = dphi_x(residues_norms);
        weighted_residues = multiscale(weights, residues);
        alternate_weighted_residues = ...
                              multiprod(multitransp(C), weighted_residues);
        
        % We write the code for the gradient in this way to avoid looping
        % over k elements, seen as k may be of order m^2 and Matlab doesn't
        % like big loops. An equivalent but much slower code is given
        % below, for readability.
        for k1 = 1 : d
            for k2 = 1 : p
                G(k1, k2, :) = - maskI * (squeeze(weighted_residues(k1, k2, :))) ...
                               + maskJ * (squeeze(alternate_weighted_residues(k1, k2, :)));
            end
        end
        
        G = manifold.to2D(G);
        G = G / k;
        
    end

end


% Slow code kept here to help with readability: this is equivalent
% to what the code in egrad with maskI and maskJ does.
% for kk = 1 : k
%     i = I(kk);
%     j = J(kk);
%     G(:, :, i) = G(:, :, i) -           weighted_residues(:, :, kk);
%     G(:, :, j) = G(:, :, j) + alternate_weighted_residues(:, :, kk);
% end
