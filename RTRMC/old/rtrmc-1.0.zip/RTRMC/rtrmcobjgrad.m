function grad = rtrmcobjgrad(problem, U)
% Helper function for RTRMC
    
    [val grad] = rtrmcobjective(problem, U); %#ok<ASGLU>

end
