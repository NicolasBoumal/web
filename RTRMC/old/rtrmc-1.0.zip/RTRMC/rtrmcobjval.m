function val = rtrmcobjval(problem, U)
% Helper function for RTRMC

    val = rtrmcobjective(problem, U);

end