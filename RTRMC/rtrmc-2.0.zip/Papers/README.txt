The preconditioner and conjugate gradients algorithm are explained in a revised version of the extended paper.
To obtain a copy, contact nicolasboumal@gmail.com
Nov. 19, 2013