function val = sqfrobnormfactors(A, B, X, Y)
% FUNCTION VAL = SQFROBNORMFACTORS(A, B, X, Y)
%
% Inputs:
%   A, X: m-by-r matrices
%   B, Y: r-by-n matrices
%
% Output:
%   val = ||AB-XY||^2_F (squared Frobenius norm of the m-by-n matrix AB-XY)
%
% Complexity:
%   O((m+n)*r^2)
%
% Accuracy:
%   val is obtained as the difference of two potentially large and very
%   close numbers, which is known to be error prone in fixed precision
%   arithmetic. Consequently, this function is not reliable if val is
%   expected to be very small compared to the squared Frobenius norms of
%   AB or XY (which are equivalent in that event).
%   When a potential accuracy drop is detected, the algorithm randomly
%   selects 50,000 entries of the matrix AB-XY, computes them and returns
%   their mean sum of squares as a proxy.
%
% Nicolas Boumal, UCLouvain, Sept. 6, 2011.
% http://perso.uclouvain.be/nicolas.boumal/RTRMC/
%
% SEE ALSO: rtrmc

%     keyboard;

    % Use Bart's trick to compute the squared Frobenius norm of AB-XY in a
    % cheap and numerically robust way:
    % Notice that AB-XY = [A X] * [B' -Y']' ; compute thin QR of each term:
    [Q1 R1] = qr([A X], 0); %#ok
    [Q2 R2] = qr([B' -Y'], 0); %#ok
    % Then by invariance of the Frobenius norm under the orthonormal
    % transformations Q1 and Q2, we simply get:
    val = norm(R1*R2', 'fro')^2;
    % And this is accurate up to 7 digits even close to 0, as compared with
    % quadruple precision computations. Thanks Bart! :)

%     A = mp(A, 34);
%     B = mp(B, 34);
%     X = mp(X, 34);
%     Y = mp(Y, 34);
% 
%     norm1 = trace((X'*X)*(Y*Y'));
%     norm2 = trace((A'*A)*(B*B'));
%     innerprod = trace((A'*X)*(Y*B'));
%     val = norm1+norm2-2*innerprod;
%     
%     val = double(val);

%     if val < 1e1 * min(eps(norm1), eps(norm2))
% % %         warning('RTRMC:sqfrobnormfactors', ...
% % %                 'The output of sqfrobnormfactors might not be reliable.');
% % %         disp('sqfrobnormfactors: stochastic computation :/');
% %         m = size(A, 1);
% %         n = size(B, 2);
% %         [I J k] = randmask(m, n, min(m*n, 50000), 1);
% %         AB = spmaskmult(A, B, I, J);
% %         XY = spmaskmult(X, Y, I, J);
% %         val = sum((AB-XY).^2)*m*n/k;

        % Added on April 18, 2013 to (attempt to) prevent rounding errors
        % ... don't know if it will work yet. -- No it doesn't.
%         if norm1 > norm2
%             val = norm1*(1 + norm2/norm1 - 2*innerprod/norm1);
%         else
%             val = norm2*(norm1/norm2 + 1 - 2*innerprod/norm2);
%         end

%     end
    
end
