function store = getStore(problem, x, storedb) %#ok<STOUT,INUSD>

    error('This file was removed from Manopt. Please use the StoreDB class.');

end
