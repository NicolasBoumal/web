%%
%
% Example script for SIAM OP 2023 Tutorial
% on Riemannian Optimization, June 3rd 2023.
%
% Nicolas Boumal
% https://www.nicolasboumal.net/SIAMOP2023/
%
clear; clc;

%%
% Load a graph -- you can generate one with generate_graph.m
data = load('graph20.mat');
n = data.n;    % number of nodes
A = data.A;    % adjacency matrix
XY = data.XY;  % positions of graph nodes

hfig = figure(1);
clf(hfig, "reset");
draw_graph(XY, A);

%%
p = 3; % Relax to unit sphere in R^p

problem.M = obliquefactory(p, n);
problem.cost = @(X) sum((X*A) .* X, 'all');
problem.egrad = @(X) 2*X*A;
problem.ehess = @(X, Xdot) 2*Xdot*A;

%%
checkgradient(problem);  % just for debugging

%%
checkhessian(problem);   % just for debugging

%%
X = trustregions(problem);  % ru nthe optimization solver

%% Show solution of Riemannian solver
if p == 2
    plot(X(1,:), X(2,:), 'k.', 'MarkerSize', 10);
    axis equal; xlim([-1.1, 1.1]); ylim([-1.1, 1.1]);
end
if p == 3
    [sx, sy, sz] = sphere(50);
    surf(sx, sy, sz, ...
        'FaceAlpha', .7, ...
        'FaceColor', [251 229 214]/255);
    hold all;
    plot3(1.02*X(1, :), 1.02*X(2, :), 1.02*X(3, :), 'k.', 'MarkerSize', 30);
    axis equal; xlim([-1.1, 1.1]); ylim([-1.1, 1.1]); zlim([-1.1, 1.1]);
    axis off;
end

%% "Round" the solution to {+1, -1}
% We now turn the matrix X into a cut.
% We can either use random rounding as follows:
% s = sign(X'*randn(p, 1));
% Or we can extract the "PCA direction" of the points
% in X and cut orthogonally to that direction, as follows:
[U, ~, ~] = svd(X', 0);
s = sign(U(:, 1)); % vector of +1's and -1's clustering nodes
% The value of the cut is computed as follows:
L = diag(sum(A, 2)) - A;
cutvalue = (s'*L*s)/4;


%% Plot the graph
hfig = figure(1);
clf(hfig, "reset");
draw_graph(XY, A, s);
