%% Script to create a graph by clicking in a plot.
%
% Example script for SIAM OP 2023 Tutorial
% on Riemannian Optimization, June 3rd 2023.
%
% Nicolas Boumal
% https://www.nicolasboumal.net/SIAMOP2023/
%

hfig = figure(1);
clf(hfig, "reset");
draw_graph([], []);

% Obtain n nodes (by clicks), and connect pairs
% at distance less than r away from each other.
n = 25;
r = .3;
XY = zeros(n, 2);
A = zeros(n);
for k = 1 : n
    [x1, x2] = ginput(1);
    XY(k, :) = [x1, x2];
    for q = 1 : k-1
        if norm(XY(q, :) - XY(k, :)) <= r
            plot(XY([k, q], 1), XY([k, q], 2), 'k-');
            A(k, q) = 1;
            A(q, k) = 1;
        end
    end
    plot(x1, x2, 'k.', 'MarkerSize', 25);
    drawnow;
end

% Save the node positions and adjacency matrix in a data file.
fname = sprintf('graph%d.mat', n);
save(fname, 'A', 'XY', 'n', '-mat');
