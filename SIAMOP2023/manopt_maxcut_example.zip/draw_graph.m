function draw_graph(XY, A, s)
% Draw a graph with n nodes at positions in XY (n-by-2)
% and adjacency matrix A (symmetric, n-by-n).
% If s is provided (n-by-1), then nodes are colored
% according to the values in s.
%
% Nicolas Boumal, June 3rd, 2023

    n = size(A, 1);

    plot([0 0 1 1 0], [0 1 1 0 0], 'k--');
    axis tight; axis equal; axis off;
    set(gcf, 'Color', 'w');

    if n <= 0
        return;
    end

    hold all;
    for k = 1 : n
        for q = 1 : k-1
            if A(k, q) > 0
                plot(XY([k, q], 1), XY([k, q], 2), ...
                    'k-', 'LineWidth', 1.5);
            end
        end
    end

    if exist('s', 'var') && ~isempty(s)
        scatter(XY(:, 1), XY(:, 2), ...
            100, s, 'filled');
        colormap([237 125 49 ; 68 114 196]/255);
    else
        scatter(XY(:, 1), XY(:, 2), ...
            100, ones(n, 1), 'filled');
        colormap([0 0 0]/255);
    end

    hold off;

end
