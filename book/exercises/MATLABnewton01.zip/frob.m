%% Frobenius inner product
% Input : Matzrices A and B
% Output : Frobenius inner product of A and B

function prod = frob(A,B)
% Perform the Frobenius product of two matrices
            
% Check matrix size
    if ~isequal(size(A),size(B))
        error('MATLAB:frobprod:sizesMustMatch', ...
                    'Matrix sizes must agree.');
    end
    prod = A(:)'*B(:);
end