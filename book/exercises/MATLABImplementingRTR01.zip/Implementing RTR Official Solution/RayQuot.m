%% Computation of the Rayleigh quotient

% Setup of the parameteres for the problem
% min f on the d-1 dimensional sphere with f(x) = x'Ax.
% We see the sphere as a Riemannian subamnigold of R^d.
% We have that gradf(x) = Proj_x(2Ax) = 2 (A- x'Ax)x 
% with Proj_x(v) = (I - xx')v.
% Riemannian Hessianf(x)[v] = 2((I-xx')Av - x'Axv)

function [f,g,H] = RayQuot(A,x,v,p)
f = x'*A*x;
g = zeros(size(x));
H = zeros(size(x));
if p.g
    g = 2 * (A*x - f*x);
end
if p.H
    H = 2 * ((eye(size(A)) - x*x')*A*v - f*v);
end
end