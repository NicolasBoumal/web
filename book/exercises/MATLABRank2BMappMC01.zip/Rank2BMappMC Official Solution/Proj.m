%% Implementation of orthogonal projection for oblique manifold

function V = Proj(Y,V,params)

for i=1:params.n
    V(i,:) = V(i,:) * (eye(params.p) - (Y(i,:)'*Y(i,:)));
end
end