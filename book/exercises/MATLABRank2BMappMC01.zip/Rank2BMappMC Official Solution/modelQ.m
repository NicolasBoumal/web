%% Used model in Riemannian Trust Regions
% This is the model m_x(v) = f(x) + (gradf(x),v)_x + 0.5 * (H(x)[v],v)_x
% for the RTR.
% Input : - (x,v) in TM.
%         - params.
%         - fhandle, which takes as input (x,v) in TM and computes function 
%           value and Riemannian gradient at x and Riemannian hessian at x.
%           in direction v.
% Output : - m_x(v).

function m = modelQ(x,v,fhandle,params)

% Computation of f(x), gradf(x) and H(x)[v]
p.f = true; p.g = true; p.H = true;
[f,g,H] = fhandle(x,v,p);

% Computation of m_x(v)
m = f + params.scal(x,g,v) + 0.5 * params.scal(x,H,v);

end