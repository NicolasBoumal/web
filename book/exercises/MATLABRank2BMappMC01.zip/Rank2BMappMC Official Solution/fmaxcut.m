%% Implementation of fmaxcut

function [f,g,H] = fmaxcut(C,Y,V,p,params)
f = trace(C*(Y*Y'));
g = zeros(size(Y));
H = zeros(size(Y));
S = C - diag(diag(C*(Y*Y')));
if p.g
    g = 2*S*Y;
end
if p.H
    H = 2 * Proj(Y,S*V,params);
end
end