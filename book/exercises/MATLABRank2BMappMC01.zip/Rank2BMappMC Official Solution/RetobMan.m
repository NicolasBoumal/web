%% Implementation of a retraction for oblique manifold


function Y = RetobMan(Y,V,params)
for i=1:params.n
    Y(i,:) = cos(norm(V(i,:)))*Y(i,:) + sin(norm(V(i,:))) * V(i,:) / norm(V(i,:));
end
end